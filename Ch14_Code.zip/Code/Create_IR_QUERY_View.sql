

DDECLARE
 v_sql VARCHAR2(4000);
 BEGNI
 
 v_sql := 'CREATE OR REPLACE VIEW MY_IR_VIEW AS '||v_ir_query;
 EXECUTE IMMEDIATE v_sql;
 
 