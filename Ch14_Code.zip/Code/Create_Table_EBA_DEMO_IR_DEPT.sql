--------------------------------------------------------
--  File created - Monday-July-06-2015   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table EBA_DEMO_IR_DEPT
--------------------------------------------------------

  CREATE TABLE"EBA_DEMO_IR_DEPT" 
   (	"DEPTNO" NUMBER(2,0), 
	"DNAME" VARCHAR2(14), 
	"LOC" VARCHAR2(13)
   ) ;
REM INSERTING into EBA_DEMO_IR_DEPT
SET DEFINE OFF;
Insert into EBA_DEMO_IR_DEPT (DEPTNO,DNAME,LOC) values (10,'ACCOUNTING','NEW YORK');
Insert into EBA_DEMO_IR_DEPT (DEPTNO,DNAME,LOC) values (20,'RESEARCH','DALLAS');
Insert into EBA_DEMO_IR_DEPT (DEPTNO,DNAME,LOC) values (30,'SALES','CHICAGO');
Insert into EBA_DEMO_IR_DEPT (DEPTNO,DNAME,LOC) values (40,'OPERATIONS','BOSTON');
--------------------------------------------------------
--  DDL for Index EBA_DEMO_IR_DEPT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX"EBA_DEMO_IR_DEPT_PK" ON"EBA_DEMO_IR_DEPT" ("DEPTNO") 
  ;
--------------------------------------------------------
--  Constraints for Table EBA_DEMO_IR_DEPT
--------------------------------------------------------

  ALTER TABLE"EBA_DEMO_IR_DEPT" ADD CONSTRAINT "EBA_DEMO_IR_DEPT_PK" PRIMARY KEY ("DEPTNO") ENABLE;
 
  ALTER TABLE"EBA_DEMO_IR_DEPT" MODIFY ("DEPTNO" NOT NULL ENABLE);
